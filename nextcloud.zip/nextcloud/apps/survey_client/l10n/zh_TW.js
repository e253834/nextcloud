OC.L10N.register(
    "survey_client",
    {
    "An error occurred while sending your report." : "送出報告時發生錯誤。",
    "Usage survey" : "用量調查",
    "Never" : "絕不"
},
"nplurals=1; plural=0;");
