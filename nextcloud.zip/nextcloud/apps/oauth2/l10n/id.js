OC.L10N.register(
    "oauth2",
    {
    "OAuth 2.0 clients" : "Klien OAuth 2.0",
    "Add client" : "Tambah klien",
    "Name" : "Nama",
    "Redirection URI" : "URI Pengalihan",
    "Add" : "Tambah",
    "Client Identifier" : "Identifier klien",
    "Secret" : "Rahasia",
    "Delete" : "Hapus"
},
"nplurals=1; plural=0;");
