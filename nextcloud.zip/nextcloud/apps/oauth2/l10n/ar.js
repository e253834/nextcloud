OC.L10N.register(
    "oauth2",
    {
    "Name" : "الإسم",
    "Redirection URI" : "رابط إعادة التوجيه",
    "Client Identifier" : "مُعرِّف العميل",
    "Secret" : "السر",
    "Add client" : "إضافة عميل",
    "Add" : "إضافة"
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");
