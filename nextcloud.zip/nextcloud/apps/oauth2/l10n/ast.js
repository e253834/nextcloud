OC.L10N.register(
    "oauth2",
    {
    "OAuth 2.0" : "OAuth 2.0",
    "OAuth 2.0 clients" : "Veceros d'OAuth 2.0",
    "Add client" : "Amestar veceru",
    "Name" : "Nome",
    "Redirection URI" : "URI de redireición",
    "Add" : "Amestar",
    "Client Identifier" : "Identificador del veceru",
    "Secret" : "Secretu",
    "Delete" : "Desaniciar"
},
"nplurals=2; plural=(n != 1);");
