OC.L10N.register(
    "oauth2",
    {
    "OAuth 2.0 clients" : "Clientes OAuth 2.0",
    "Add client" : "Agregar cliente",
    "Name" : "Nombre",
    "Redirection URI" : "URI para redirección",
    "Add" : "Agregar",
    "Client Identifier" : "Identificador del cliente",
    "Secret" : "Secreto",
    "Delete" : "Borrar"
},
"nplurals=2; plural=(n != 1);");
