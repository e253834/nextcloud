OC.L10N.register(
    "oauth2",
    {
    "OAuth 2.0" : "OAuth 2.0",
    "OAuth 2.0 clients" : "OAuth 2.0-kliënte",
    "Add client" : "Voeg kliënt toe",
    "Name" : "Naam",
    "Redirection URI" : "Herverwysings-URI",
    "Add" : "Voeg toe",
    "Client Identifier" : "Kliëntidentifiseerder",
    "Secret" : "Geheim",
    "Delete" : "Skrap"
},
"nplurals=2; plural=(n != 1);");
